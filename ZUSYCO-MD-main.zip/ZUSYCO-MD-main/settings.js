/*


███████╗██╗░░░██╗░██████╗██╗░░░██╗░█████╗░░█████╗░  ░░░░░░  ███╗░░░███╗██████╗░
╚════██║██║░░░██║██╔════╝╚██╗░██╔╝██╔══██╗██╔══██╗  ░░░░░░  ████╗░████║██╔══██╗
░░███╔═╝██║░░░██║╚█████╗░░╚████╔╝░██║░░╚═╝██║░░██║  █████╗  ██╔████╔██║██║░░██║
██╔══╝░░██║░░░██║░╚═══██╗░░╚██╔╝░░██║░░██╗██║░░██║  ╚════╝  ██║╚██╔╝██║██║░░██║
███████╗╚██████╔╝██████╔╝░░░██║░░░╚█████╔╝╚█████╔╝  ░░░░░░  ██║░╚═╝░██║██████╔╝
╚══════╝░╚═════╝░╚═════╝░░░░╚═╝░░░░╚════╝░░╚════╝░  ░░░░░░  ╚═╝░░░░░╚═╝╚═════╝░



Project Name : K29PROMAX - MD
Creator : @darkmakerofc , @mr-nima-x 

*/

module.exports = {
  OWNER_NUMBER: "263717672068",
  SUDO_NUMBERS : "263717672068,263717672068",
  OWNER_NAME: "『 k29promax 』",
  BOT_NAME : "k29promax",
  ZUSYCO_FILE : "ZUSYCO-QR",
  LOGOS: {
    ALIVE: 'https://i.ibb.co/YTWznr9/ZUSYCO-ALIVE-IMAGE-LOWQ.jpg',
    WELCOME: 'https://i.ibb.co/PzhpBV7/WELCOME-IMAGE-LOWQ.jpg',
    GOODBYE: 'https://i.ibb.co/t8hKpcM/GOODBYE-IMAGE-LOWQ.jpg'
  },
  STOP_SEND : {
        WELCOME_MESSAGE : false,
        GOODBYE_MESSAGE : false
    },
  DESABLE_WELCOME_GOODBYE_JIDS : [],
  TIME_ZONE :  "Asia/Colombo",
  WORK_TYPE : "public",
  WORK_MODE : "public",
  WORK_MODE_MESSAGE_SEND : false,
  CAPTION : '© Created by k29promax',
  STICKER_PACK : '[ ZUSYCO ]',
  BAD_WORDS : 'fuck,pussy',
  ANTI_BAD : false,
  ANTI_LINKS : 'chat.whatsapp.com',
  ANTI_LINK : false,
  ANTI_LINK_KICK : false,
  MAX_SIZE : 100,
  MOROCCO_NUMBERS : {
        BLOCK : false,
        NOT_WORKING : false,
  },
  READ : {
     ALL_MESSAGES : false,
     ONLY_COMMANDS : 'true',
     STATUS : "true",
  },
  BOT_OFFLINE : false,
  INBOX_BLOCK : false,
  AUTO_REACT : false,
  OWNER_REACT : '🤵‍♂️',
  AUTO_BGM : false,
  BGM : {
    "chaio" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-caio.mp3",
    "leo" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-leo.mp3",
    "tance" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-tance0.mp3",
    "romant" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-floot.mp3",
    "serio" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-serio.mp3",
    "chill" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-wichil.mp3",
    "yaka" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-yaka.mp3",
    "animel" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-animel.mp3",
    "bitch" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-bitch.mp3",
    "papa" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-papa.mp3",
    "shee" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-sheela.mp3",
    "thugs" : "https://github.com/MR-NIMA-X/ZUSYCO-DB/raw/main/media/audios/ZUSYCO-thugs.mp3",

  },
  AUTO_STICKER : false,
  STICKERS : {
    "pit" : "https://i.ibb.co/NVLMQDP/pit.webp",
    "agei" : "https://i.ibb.co/yqk8QQ9/agei.webp",
    "ne" : "https://i.ibb.co/N6Wb6mZ/ne.webp",
  },
  LOAD_ANIMATION : false,
 
};
