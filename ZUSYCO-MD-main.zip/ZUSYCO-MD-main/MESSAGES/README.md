### English : You Can Change Your alive , welcome , goodbye messages using this files.

[`ALIVE MESSAGE`](/MESSAGES/ALIVE_MESSAGE.txt) <br>
[`WELCOME MESSAGE`](/MESSAGES/WELCOME_MESSAGE.txt)<br>
[`GOODBYE MESSAGE`](/MESSAGES/GOODBYE_MESSAGE.txt)<br><br>

### English : මෙහි ඇති Files බාවිතයෙන් ඔබට, ඔබගේ bot ගේ alive , welcome , goodbye පණිවිඩ වෙනස් කල හැක.

[`ALIVE MESSAGE`](/MESSAGES/ALIVE_MESSAGE.txt) <br>
[`WELCOME MESSAGE`](/MESSAGES/WELCOME_MESSAGE.txt)<br>
[`GOODBYE MESSAGE`](/MESSAGES/GOODBYE_MESSAGE.txt)<br><br><br><br><br>


[`Go Back`](/README.md)
